<div class="row">
	<div class="col-md-2">
		<h1> Sistem Pendukung Keputusan Peminatan Siswa SMA <br> di SMA Negeri 1 Bojong</h1>
	</div>
	
</div>