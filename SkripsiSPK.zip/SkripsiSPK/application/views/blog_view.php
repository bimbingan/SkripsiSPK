<html> 
	<head> 
	<title>Blog Saya</title>
	</head>
	<body>
		<h2>Selamat Datang di Blog Saya</h2>
	</body>
</html>