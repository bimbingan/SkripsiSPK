<ul id="menu_tab">
	<li id="tab_peminatan"><?php echo anchor('peminatan', 'Peminatan');?></li>
	<li id="tab_siswa"><?php echo anchor('siswa', 'Siswa');?></li>
	<li id="tab_logout"><?php echo anchor('logout', 'Logout');?></li>	
</ul>