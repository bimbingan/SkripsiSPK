<?php 
	class Blog extends CI_Controller {
		public function index()
		{
			echo 'Halo, Selamat datang di Sistem Pendukung Keputusan Peminatan SMA';
		}
	}
?>